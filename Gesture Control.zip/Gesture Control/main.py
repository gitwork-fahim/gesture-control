import cv2
import time
import pyautogui
from gesture_detector import GestureDetector
from mouse_controller import MouseController

class GestureControlApp:
    def __init__(self):
        # Get screen size
        self.screen_width, self.screen_height = pyautogui.size()
        
        # Initialize components
        self.detector = GestureDetector()
        self.mouse = MouseController(self.screen_width, self.screen_height)
        
        # Camera
        self.cap = cv2.VideoCapture(0)
        self.cap.set(3, 640)  # Width
        self.cap.set(4, 480)  # Height
        
        # State management
        self.current_gesture = "none"
        self.gesture_hold_start = 0
        self.hold_duration = 0.3  # Hold gesture for 0.3s to activate
        self.last_action = 0
        self.action_cooldown = 1.0
        
        # FPS
        self.prev_time = 0
        
        print("=" * 50)
        print("🚀 GESTURE CONTROL SYSTEM STARTED!")
        print("=" * 50)
        print("\n📋 GESTURE CONTROLS:")
        print("☝️  Point          → Move Cursor")
        print("🤏  Pinch          → Left Click")
        print("✌️  Two Fingers    → Right Click")
        print("👍  Thumbs Up      → Scroll Up")
        print("👎  Thumbs Down    → Scroll Down")
        print("🖐️  Open Hand      → Toggle Drag")
        print("✊  Fist           → Pause/Resume")
        print("🤘  Rock On        → Alt+Tab")
        print("\n⚠️  Press 'Q' to quit")
        print("⚠️  Move mouse to top-left corner for emergency stop")
        print("=" * 50)
    
    def run(self):
        """Main application loop"""
        while True:
            success, frame = self.cap.read()
            if not success:
                break
            
            # Flip frame horizontally (mirror)
            frame = cv2.flip(frame, 1)
            
            # Detect hands
            frame = self.detector.find_hands(frame)
            landmark_list = self.detector.find_position(frame)
            
            # Draw hands
            frame = self.detector.draw_hands(frame)
            
            # Process gestures
            if len(landmark_list) != 0:
                gesture, confidence = self.detector.detect_gesture(landmark_list)
                self.process_gesture(gesture, landmark_list, frame)
                
                # Display current gesture
                cv2.putText(frame, f"Gesture: {gesture}", (10, 30), 
                           cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 255, 0), 2)
                cv2.putText(frame, f"Confidence: {confidence}%", (10, 60), 
                           cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0, 255, 255), 2)
            else:
                cv2.putText(frame, "No Hand Detected", (10, 30), 
                           cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 0, 255), 2)
            
            # Display status
            status = "PAUSED" if self.mouse.is_paused else "ACTIVE"
            color = (0, 0, 255) if self.mouse.is_paused else (0, 255, 0)
            cv2.putText(frame, f"Status: {status}", (10, 90), 
                       cv2.FONT_HERSHEY_SIMPLEX, 0.7, color, 2)
            
            # Display FPS
            current_time = time.time()
            fps = 1 / (current_time - self.prev_time) if self.prev_time != 0 else 0
            self.prev_time = current_time
            cv2.putText(frame, f"FPS: {int(fps)}", (10, frame.shape[0] - 10), 
                       cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255, 0, 255), 2)
            
            # Show frame
            cv2.imshow("Gesture Control - Press Q to Quit", frame)
            
            # Quit on 'Q' key
            if cv2.waitKey(1) & 0xFF == ord('q'):
                break
        
        self.cleanup()
    
    def process_gesture(self, gesture, landmark_list, frame):
        """Process detected gesture and perform action"""
        current_time = time.time()
        
        # Check if gesture held long enough
        if gesture != self.current_gesture:
            self.current_gesture = gesture
            self.gesture_hold_start = current_time
        
        hold_time = current_time - self.gesture_hold_start
        
        # Point gesture - Move cursor (instant, no hold required)
        if gesture == "point":
            index_tip = landmark_list[8]
            self.mouse.move_cursor(index_tip[1], index_tip[2], 
                                  frame.shape[1], frame.shape[0])
            return
        
        # Other gestures require hold time
        if hold_time < self.hold_duration:
            return
        
        # Cooldown check
        if current_time - self.last_action < self.action_cooldown:
            return
        
        # Execute gesture actions
        action_performed = False
        
        if gesture == "pinch":
            if self.mouse.left_click():
                print("🖱️ LEFT CLICK")
                action_performed = True
        
        elif gesture == "two_fingers":
            if self.mouse.right_click():
                print("🖱️ RIGHT CLICK")
                action_performed = True
        
        elif gesture == "thumbs_up":
            self.mouse.scroll_up(100)
            print("⬆️ SCROLL UP")
            action_performed = True
        
        elif gesture == "thumbs_down":
            self.mouse.scroll_down(100)
            print("⬇️ SCROLL DOWN")
            action_performed = True
        
        elif gesture == "open_hand":
            if self.mouse.is_dragging:
                self.mouse.stop_drag()
                print("✋ DRAG OFF")
            else:
                self.mouse.start_drag()
                print("✋ DRAG ON")
            action_performed = True
        
        elif gesture == "fist":
            paused = self.mouse.toggle_pause()
            print(f"✊ {'PAUSED' if paused else 'RESUMED'}")
            action_performed = True
        
        elif gesture == "rock_on":
            self.mouse.hotkey('alt', 'tab')
            print("🤘 ALT+TAB")
            action_performed = True
        
        if action_performed:
            self.last_action = current_time
    
    def cleanup(self):
        """Clean up resources"""
        self.cap.release()
        cv2.destroyAllWindows()
        print("\n✅ Gesture Control System stopped.")

if __name__ == "__main__":
    app = GestureControlApp()
    app.run()
