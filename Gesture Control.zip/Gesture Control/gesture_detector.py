import cv2
import mediapipe as mp
import math

class GestureDetector:
    def __init__(self):
        self.mp_hands = mp.solutions.hands
        self.hands = self.mp_hands.Hands(
            static_image_mode=False,
            max_num_hands=1,
            min_detection_confidence=0.7,
            min_tracking_confidence=0.7
        )
        self.mp_draw = mp.solutions.drawing_utils
        
    def find_hands(self, frame):
        """Detect hands in frame"""
        frame_rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        self.results = self.hands.process(frame_rgb)
        return frame
    
    def find_position(self, frame, hand_no=0):
        """Get landmark positions"""
        landmark_list = []
        if self.results.multi_hand_landmarks:
            if len(self.results.multi_hand_landmarks) > hand_no:
                hand = self.results.multi_hand_landmarks[hand_no]
                
                for id, lm in enumerate(hand.landmark):
                    h, w, c = frame.shape
                    cx, cy = int(lm.x * w), int(lm.y * h)
                    landmark_list.append([id, cx, cy, lm.x, lm.y, lm.z])
                    
        return landmark_list
    
    def draw_hands(self, frame):
        """Draw hand landmarks on frame"""
        if self.results.multi_hand_landmarks:
            for hand_landmarks in self.results.multi_hand_landmarks:
                self.mp_draw.draw_landmarks(
                    frame, 
                    hand_landmarks, 
                    self.mp_hands.HAND_CONNECTIONS
                )
        return frame
    
    def get_finger_states(self, landmark_list):
        """Detect which fingers are up"""
        if len(landmark_list) == 0:
            return []
        
        fingers = []
        
        # Thumb (check x-axis)
        if landmark_list[4][1] < landmark_list[3][1]:  # Left hand
            fingers.append(1)
        else:
            fingers.append(0)
        
        # Other 4 fingers (check y-axis)
        tips = [8, 12, 16, 20]
        pips = [6, 10, 14, 18]
        
        for tip, pip in zip(tips, pips):
            if landmark_list[tip][2] < landmark_list[pip][2]:
                fingers.append(1)
            else:
                fingers.append(0)
        
        return fingers
    
    def detect_gesture(self, landmark_list):
        """Detect specific gestures"""
        if len(landmark_list) == 0:
            return "none", 0
        
        fingers = self.get_finger_states(landmark_list)
        
        if len(fingers) != 5:
            return "none", 0
        
        # Calculate thumb-index distance for pinch
        thumb_tip = landmark_list[4]
        index_tip = landmark_list[8]
        distance = math.sqrt(
            (thumb_tip[1] - index_tip[1])**2 + 
            (thumb_tip[2] - index_tip[2])**2
        )
        
        # Gesture detection
        # Pinch (Click)
        if distance < 30:
            return "pinch", 95
        
        # Point (Move cursor) - only index up
        if fingers == [0, 1, 0, 0, 0]:
            return "point", 90
        
        # Two Fingers (Right Click)
        if fingers == [0, 1, 1, 0, 0]:
            return "two_fingers", 90
        
        # Thumbs Up (Scroll Up)
        if fingers == [1, 0, 0, 0, 0]:
            return "thumbs_up", 90
        
        # Thumbs Down (Scroll Down)
        if fingers == [0, 0, 0, 0, 0] and landmark_list[4][2] > landmark_list[0][2]:
            return "thumbs_down", 90
        
        # Open Hand (Drag mode)
        if fingers == [1, 1, 1, 1, 1]:
            return "open_hand", 90
        
        # Fist (Pause)
        if fingers == [0, 0, 0, 0, 0]:
            return "fist", 90
        
        # Rock On (Special action)
        if fingers == [0, 1, 0, 0, 1]:
            return "rock_on", 90
        
        # OK Sign (Enter key)
        if distance < 30 and fingers[2] == 1 and fingers[3] == 1 and fingers[4] == 1:
            return "ok_sign", 90
        
        return "unknown", 50