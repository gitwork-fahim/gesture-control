import pyautogui
import time

class MouseController:
    def __init__(self, screen_width=1920, screen_height=1080):
        self.screen_width = screen_width
        self.screen_height = screen_height
        
        # PyAutoGUI settings
        pyautogui.FAILSAFE = True  # Move mouse to corner to stop
        pyautogui.PAUSE = 0.01
        
        # Control state
        self.is_paused = False
        self.is_dragging = False
        self.last_click_time = 0
        self.click_delay = 0.5  # Prevent double clicks
        
        # Smoothing for cursor movement
        self.prev_x = 0
        self.prev_y = 0
        self.smoothing = 0.7
        
    def move_cursor(self, x, y, frame_width, frame_height):
        """Move cursor based on hand position"""
        if self.is_paused:
            return
        
        # Convert hand coordinates to screen coordinates
        screen_x = int((x / frame_width) * self.screen_width)
        screen_y = int((y / frame_height) * self.screen_height)
        
        # Smooth cursor movement
        screen_x = int(self.prev_x * self.smoothing + screen_x * (1 - self.smoothing))
        screen_y = int(self.prev_y * self.smoothing + screen_y * (1 - self.smoothing))
        
        # Move cursor
        pyautogui.moveTo(screen_x, screen_y)
        
        self.prev_x = screen_x
        self.prev_y = screen_y
    
    def left_click(self):
        """Perform left click with delay"""
        current_time = time.time()
        if current_time - self.last_click_time > self.click_delay:
            pyautogui.click()
            self.last_click_time = current_time
            return True
        return False
    
    def right_click(self):
        """Perform right click"""
        current_time = time.time()
        if current_time - self.last_click_time > self.click_delay:
            pyautogui.rightClick()
            self.last_click_time = current_time
            return True
        return False
    
    def scroll_up(self, amount=100):
        """Scroll up"""
        pyautogui.scroll(amount)
    
    def scroll_down(self, amount=100):
        """Scroll down"""
        pyautogui.scroll(-amount)
    
    def start_drag(self):
        """Start dragging"""
        if not self.is_dragging:
            pyautogui.mouseDown()
            self.is_dragging = True
    
    def stop_drag(self):
        """Stop dragging"""
        if self.is_dragging:
            pyautogui.mouseUp()
            self.is_dragging = False
    
    def press_key(self, key):
        """Press a keyboard key"""
        pyautogui.press(key)
    
    def hotkey(self, *keys):
        """Press multiple keys (like Ctrl+C)"""
        pyautogui.hotkey(*keys)
    
    def toggle_pause(self):
        """Pause/unpause cursor control"""
        self.is_paused = not self.is_paused
        if self.is_paused:
            self.stop_drag()
        return self.is_paused
